<?php
header("Location: ../../vistas/login.html");
?>