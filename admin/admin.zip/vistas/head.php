<!-- Icono Sevens-Ingenieros-SAC -->
<link rel="apple-touch-icon" href="../dist/svg/logo-icono.svg">
<link rel="shortcut icon" href="../dist/svg/logo-icono.svg">

<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback" />

<!-- Font Awesome -->
<!-- <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css" /> -->
<link rel="stylesheet" href="../plugins/fontawesome-free-6.2.0/css/all.min.css" />

<!-- IonIcons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

<!-- DataTables -->
<!-- <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css" />
<link rel="stylesheet" href="../plugins/datatables-responsive/css/responsive.bootstrap4.min.css" />
<link rel="stylesheet" href="../plugins/datatables-buttons/css/buttons.bootstrap4.min.css" /> --> 
 
<link rel="stylesheet" type="text/css" href="../plugins/datatables2/jquery.dataTables.min.css">    
<link rel="stylesheet" type="text/css" href="../plugins/datatables2/buttons.dataTables.min.css" rel="stylesheet"/>
<link rel="stylesheet" type="text/css" href="../plugins/datatables2/responsive.dataTables.min.css" rel="stylesheet"/>

<!-- Bootstrap Color Picker -->
<link rel="stylesheet" href="../plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">

<!-- Select2 -->
<link rel="stylesheet" href="../plugins/select2/css/select2.min.css">
<link rel="stylesheet" href="../plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">

<!-- Toastr -->
<link rel="stylesheet" href="../plugins/toastr/toastr.min.css">

<!-- bootstrap-datepicker -->
<link rel="stylesheet" href="../plugins/bootstrap-datepicker-master/dist/css/bootstrap-datepicker.css" />

<!-- daterange picker -->
<!-- <link rel="stylesheet" href="../plugins/daterangepicker/daterangepicker.css"> -->

<!-- Tempusdominus Bootstrap 4 -->
<link rel="stylesheet" href="../plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.css">

<!-- Theme style -->
<link rel="stylesheet" href="../dist/css/adminlte.min.css" />

<!-- style nuevo -->
<link rel="stylesheet" href="../dist/css/style_new.css" />

<!-- style go-to -->
<link rel="stylesheet" href="../dist/css/go-to.css">

<!-- texto parpadeante -->
<link rel="stylesheet" href="../dist/css/texto_parpadeante.css" />

<!-- Print PDF -->
<link rel="stylesheet" href="../plugins/print-pdf-1.5.0/print.min.css">